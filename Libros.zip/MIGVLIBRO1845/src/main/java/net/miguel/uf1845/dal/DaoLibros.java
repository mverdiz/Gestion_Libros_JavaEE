package net.miguel.uf1845.dal;

import net.miguel.uf1845.modelos.*;

public interface DaoLibros extends Dao<Libro> {
	
}
